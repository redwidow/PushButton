package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class GameActivity extends AppCompatActivity {




    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.game);


        TextView GameMessage = findViewById(R.id.NameWelcome);
        TextView counter = findViewById(R.id.Counter);
        Button GameBTN = findViewById(R.id.CounterButton);
        counter.setText("0");
        Intent thisInt = getIntent();
        String UserName = thisInt.getStringExtra("User_name");
        GameMessage.setText("Good Luck" + " " + UserName);
        GameBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int counterValue = Integer.parseInt(counter.getText().toString());
                counterValue += 1;

                if (counterValue == 21) {
                    Toast.makeText(getApplicationContext(), "Sorry, Cannot count higher.", Toast.LENGTH_LONG).show();
                } else {
                    counter.setText(String.valueOf(counterValue));
                }

                if (counterValue > 22) {
                    Intent winner = new Intent(GameActivity.this, WinnerActivity.class);
                    startActivity(winner);
                }
            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

    }

}